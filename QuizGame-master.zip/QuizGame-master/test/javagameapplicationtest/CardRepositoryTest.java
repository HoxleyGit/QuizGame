/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javagameapplicationtest;

import javagameapplication.CardRepository;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kamil Matecki
 */
public class CardRepositoryTest {
    
    public CardRepositoryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void constructorOfCardRepositoryTest(){
        CardRepository cardRepository = new CardRepository();
        assertNotNull(cardRepository.getRegistryCardList());
        assertEquals(370, cardRepository.getRegistryCardList().size());
    }
}
